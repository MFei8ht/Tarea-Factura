package tarea_tema1_2;

/**
 *
 * @author Octavio Becerril Olivares
 */
public class PruebaFactura {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Factura facturap = new Factura("2132141", "tornillo", 9, 9);
        
        System.out.print("El numero de la pieza es: "+facturap.getNumPieza()+"\t"+"\t");
        System.out.print("La descripcion de la pieza es: "+facturap.getDesPieza()+"\t"+"\t");
        System.out.print("La cantidad de piezas es: "+facturap.getCantArt()+"\t"+"\t");
        System.out.println("El precio del articulo es: "+facturap.getPrecioArt());
        
        
        System.out.println(facturap.obtenerMontoFactura(facturap.getCantArt(), facturap.getPrecioArt()));
    }
    
}
