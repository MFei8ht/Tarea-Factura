package tarea_tema1_2;

public class Factura {

    private String numPieza;
    private String desPieza;
    private int cantArt;
    private double precioArt;

    public Factura(String numPieza, String desPieza, int cantArt, double precioArt) {
        this.numPieza = numPieza;
        this.desPieza = desPieza;
        this.cantArt = cantArt;
        this.precioArt = precioArt;
    }

    /**
     * @return the numPieza
     */
    public String getNumPieza() {
        return numPieza;
    }

    /**
     * @param numPieza the numPieza to set
     */
    public void setNumPieza(String numPieza) {
        this.numPieza = numPieza;
    }

    /**
     * @return the desPieza
     */
    public String getDesPieza() {
        return desPieza;
    }

    /**
     * @param desPieza the desPieza to set
     */
    public void setDesPieza(String desPieza) {
        this.desPieza = desPieza;
    }

    /**
     * @return the cantArt
     */
    public int getCantArt() {
        return cantArt;
    }

    /**
     * @param cantArt the cantArt to set
     */
    public void setCantArt(int cantArt) {
        this.cantArt = cantArt;
    }

    /**
     * @return the precioArt
     */
    public double getPrecioArt() {
        return precioArt;
    }

    /**
     * @param precioArt the precioArt to set
     */
    public void setPrecioArt(double precioArt) {
        this.precioArt = precioArt;
    }

    public double obtenerMontoFactura(int cant, double precio) {
        if (cant < 0) {
            cant = 0;
            System.out.println("el valor es de 0");
        }
        if (precio < 0) {
            precio = 0.0;
            System.out.println("el valor es de 0.0");
        }
        System.out.print("El monto de la factura es: ");

        double res = cant * precio;
        return res;
    }
}
